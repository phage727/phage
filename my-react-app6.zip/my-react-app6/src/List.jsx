import PropTypes from 'prop-types';

function List(props){
    
    const category = props.category;
    const itemList = props.items;

    /*const fruits = [{id:1, name:"orange", calories:85}, 
                    {id:2,name:"apple", calories:75},  
                    {id:3,name:"banana", calories:45}, 
                    {id:4,name:"avocado", calories:68},
                    {id:5,name:"mango", calories:60}];*/
    //fruits.sort((a, b) => a.name.localeCompare(b.name));  
    //for reverse reverse a & b 
    //fruits.sort((a, b) => a.calories- b.calories); //sort calories

    //const lowCalFruits = fruits.filter(fruit=> fruit.calories <65); //low callfruits
    //replace fruits with fruit
    const listItems =itemList.map(item => <li key={item.id}>
                                           <b>{item.name}:</b> &nbsp;
                                              {item.calories}</li>)
    
    return (<>
            <h3 className="list-category">{category}</h3>
            <ol className="list-items">{listItems}</ol>
            </>);
}
List.propTypes = {
    category: PropTypes.string,
    items: PropTypes.arrayOf(PropTypes.shape({id: PropTypes.number,
                                              name: PropTypes.string,
                                              calories: PropTypes.number  
    }))



}
List.defaultProps = {

    category:"Category",
    items:[],
}

export default List