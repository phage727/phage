import profilepic from './assets/hackernight.jpg'


function Card(){
    return(
        
        <dev className="ard">
         <img className="card-image" src={profilepic} alt="Profile picture"></img>
         <h2>Sura Hwold</h2>
         <p>I am a Web developer and Graphic Designer </p>

        </dev>
    )
   
}
export default Card